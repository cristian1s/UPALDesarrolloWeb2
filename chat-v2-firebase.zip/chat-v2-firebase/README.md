# React + Vite
# PROJECT : CHAT ONLINE v1
Homeworks:
- [✔️] create a project whith vite
- [✔️] search components of chat 
- [✔️] create JSON structure initial for chats lists and chats messages
- [✔️] create first interfaz
- [✔️] create funcionality "send message a distinct users"
- [✔️] create distincts users for the chat  
- [✔️] sicronize this messages of users with the json 
- [✔️] create alert of message not read
- [✔️ 🔥] implement mood dark and ligth
- [✔️] valitdate send message (not empty)
- [✔️] scroll infinite for charge history of messages
- [✔️] edit send messages
- [] send images 
- [✔️] event key up enter for input
- [✔️] save local storage messages and list chats
- [] select current or default active chat 
- [✔️] colocar ultimo mensaje en el chat
- [✔️] al entrar al chat se debe mostrar siempre el scroll en abajo
- [✔️] arreglar la imagen en rederizado
- [✔️] ordenar la lista de chats
- [✔️] cambiar el ordend e los user de acuerdo a los mensajes y seleccionados

# chat conect with firebase autenthicate and save messages -> PC1

- [✔️] create login UI
- [✔️] agregar routes 
- [✔️] authenthication with firebase -> gmail
- [✔️] darle credenciales al correo del profesor (gerardo.barzola.mentor@upal.edu.pe , 123456)
- [] state of text entry "tiping"
- [] state user in line "red = desactive" and "blue = active" 
- [] implemente socket.io

1. cd chat-v1
2. npm install
3. npm run dev
4. Ready :D
